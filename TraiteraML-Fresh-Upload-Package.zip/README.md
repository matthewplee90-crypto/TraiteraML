# Traitera 6.0

Traitera is a mobile-first personality and career discovery web app. This repository contains the latest standalone Traitera build, now packaged as an installable web app for Netlify.

## What is included

- `index.html` — the complete Traitera 6.0 app (all five assessments, The Inner Atlas, Inner Cast, comparisons and redesigned Career Atlas).
- `manifest.webmanifest` and `icons/` — make the site installable from Chrome's menu.
- `sw.js` — caches public application files for offline use and checks for updates when online.
- `netlify.toml` — Netlify publishing configuration.

## Connect to Netlify (once)

1. Sign in to Netlify and open **Add new project** > **Import an existing project**.
2. Choose **GitHub**, select this private repository, and authorise it if asked.
3. Publish directory: `.` (dot). No build command required.
4. Deploy. Open the generated `.netlify.app` site in Chrome, then select **Install app** or **Add to Home screen**.
5. Future commits to your connected GitHub repository will automatically deploy to Netlify.

To preserve locally saved assessments, use the same Netlify site address. Changing to a new site or domain does not automatically transfer local browser storage. Export a backup first if needed.

## AI roadmap

The current app is offline and rule-based; it does **not** call an AI model. The intended next step is to add secure Netlify Functions and Netlify AI Gateway for on-demand Inner Atlas/Career Atlas writing, with user-facing consent, model usage limits and private key management. Never insert model API keys into `index.html` or commit them to GitHub.

## Privacy

Personality answers and reports currently live in your browser's local storage. No account or remote sync is included in this prototype. A shared device can expose saved reports to other browser users, so avoid using shared profiles for private assessments.
